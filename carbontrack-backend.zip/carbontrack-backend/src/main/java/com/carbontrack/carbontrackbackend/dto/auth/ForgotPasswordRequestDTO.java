package com.carbontrack.carbontrackbackend.dto.auth;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class ForgotPasswordRequestDTO {

    @NotBlank
    @Email
    private String email;

    public ForgotPasswordRequestDTO() {
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}

